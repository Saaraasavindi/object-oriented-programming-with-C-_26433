﻿namespace Lab_01_____Qusetion_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string name;
            string Batch;
            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Enter your Batch:");
            Batch = Console.ReadLine();
        }
    }
}